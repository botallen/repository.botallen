<h2 align="center">
  <br>
  <a href="https://github.com/botallen/repository.botallen/tree/master/plugin.video.botallen.hotstar"><img src="resources/icon.jpg" height="60" width="60"></a>
  <br>
  Disney+ Hotstar
  <br>
</h2>

<h4 align="center">Disney+ Hotstar Kodi Add-on</h4>

<br>

## Download

[**Download**](https://github.com/botallen/repository.botallen/blob/master/plugin.video.botallen.hotstar/plugin.video.botallen.hotstar-0.0.1.zip) the `.zip` file.

## Disclaimer

This plugin is not officially commissioned/supported by Hotstar. The trademark "Hotstar" is registered by "Novi Digital Entertainment Private Limited (Novi)"
