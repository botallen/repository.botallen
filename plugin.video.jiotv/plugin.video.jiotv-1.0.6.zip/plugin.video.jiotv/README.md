<h2 align="center">
  <br>
  <a href="https://github.com/botallen/repository.botallen/tree/master/plugin.video.jiotv"><img src="resources/icon.png" height="60" width="60"></a>
  <br>
  JioTV Addon
  <br>
</h2>

<h4 align="center">Unofficial JioTV Kodi Addon</h4>

<br>

## Highlights

- [Simple IPTV PVR addon support](#pvr-setup)

## Download

[**Download**](https://github.com/botallen/repository.botallen/raw/master/plugin.video.jiotv/plugin.video.jiotv-1.0.6.zip) the `.zip` file.

### PVR Setup

Settings -> Setup -> Setup Simple IPTV PVR
